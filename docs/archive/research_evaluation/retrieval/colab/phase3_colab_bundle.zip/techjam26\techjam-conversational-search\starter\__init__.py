"""Participant starter package."""

