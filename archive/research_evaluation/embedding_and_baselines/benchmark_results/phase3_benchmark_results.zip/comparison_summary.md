# Embedding bake-off summary

The controlled retrieval benchmark is the primary embedding-quality evidence. No winner is declared automatically.

| Metric | BGE | OpenAI |
|---|---:|---:|
| Dense Recall@10 | 0.715000 | 0.635000 |
| Dense Recall@50 | 0.850000 | 0.825000 |
| Dense Recall@150 | 0.945000 | 0.935000 |
| Dense MRR | 0.548495 | 0.515251 |
| Median target rank | 2.000000 | 2.000000 |
| Query embedding p50 (s) | 0.015556 | 0.245929 |
| Query embedding p95 (s) | 0.026295 | 0.276277 |
| Dense-search p50 (s) | 0.012338 | 0.043980 |
| Dense-search p95 (s) | 0.015929 | 0.065913 |
| Agent respond p50 (s) | n/a | n/a |
| Agent respond p95 (s) | n/a | n/a |
| Extended HR@10 | n/a | n/a |
| Extended MRR | n/a | n/a |
| Mean turns | n/a | n/a |
| Catalog cache/build time (s) | 241.387155 | 167.128468 |
| Total evaluation time (s) | n/a | n/a |
| Embedding API requests | 0 | 250 |
| Embedding API input tokens | 0 | 3631470 |
| Failures | 0 | 0 |

End-to-end shopper runs are stochastic and are supporting, not perfectly paired, evidence.
